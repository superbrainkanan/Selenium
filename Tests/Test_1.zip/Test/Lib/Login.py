
def Login(user, password):
    print("User:      ", user)
    print("Password:  ", password)
